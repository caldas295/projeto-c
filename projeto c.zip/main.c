#include <stdio.h>
#include <stdlib.h>


struct informacoes{
float valor;
int dia,mes,ano;
char categoria[100];

};

void ListarRegistro(){

struct informacoes A;

FILE* arquivo = fopen("registros.txt","r");  

while(fscanf(arquivo,"%f %d %d %d %s", &A.valor,&A.dia,&A.mes,&A.ano,A.categoria) !=EOF){

printf("Valor: %f\n ", A.valor);
printf("Data: (%d/%d/%d)\n", A.dia, A.mes, A.ano);
printf("Categoria: %s\n ",A.categoria);

}

}


void cadastroRegistro(struct informacoes T[100]){


int resp;
int i=0;
int contador = 1;

for(i=0; i<100; i++){

  printf("Digite o valor: ");
  scanf("%f", &T[i].valor);

  printf("\nDigite o dia: ");
  scanf("%d", &T[i].dia);

  printf("\nDigite o mes: ");
  scanf("%d", &T[i].mes);

  printf("\nDigite o ano: ");
  scanf("%d", &T[i].ano);

  printf("\nCategoria:");
  scanf("%s", T[i].categoria);

  printf("Deseja adicionar mais um registro ?\n");
  printf("1 ===> SIM\n");
  printf("2 ===> NÃO\n");
  printf("\nresposta:");
  scanf("%d", &resp);
  

  if(resp == 1){
    contador++;
    }
  if(resp == 2){
     FILE* arquivo = fopen("registros.txt", "a");
    for(i=0; i<contador; i++){
      fprintf(arquivo, "%f ", T[i].valor);
      fprintf(arquivo, "(%d/%d/%d) ", T[i].dia, T[i].mes, T[i].ano);
      fprintf(arquivo, "%s\n", T[i].categoria);
     
        } 
    fclose(arquivo);
    printf("Contador: %d", contador);
    break;
    return;
    }

  } 



}




void MenuRegistro(){
struct informacoes T[100];
 
int i = 1;
int resp2 = 0;

do{ 
  printf("\n<=========== REGISTRO ===========>\n\n O que deseja fazer?\n\n");
  printf("0 - Voltar para o Menu \n");
  printf("1 - Cadastrar novo registro \n");
  printf("2 - Remover registro \n");
  printf("3 - Listar registros\n");
  printf("4 - Alterar registro\n");
  scanf("%d", &resp2);
  if(resp2 == 0){
    printf("Voltando para o menu...\n\n");
    return;
  }

  else if(resp2< 0 || resp2 > 4 ){
    printf("Esta opção não existe !!! \n ");
    printf("\n ");
  }

  else if(resp2 == 1){
    ; 
    cadastroRegistro(T);
  }

  else if(resp2 == 3){
    ListarRegistro();
  }

}while(resp2 >= 0 || resp2 <=4 );

}


void menu(){
int resp1 = 0; 


do{

  printf("<=========== MENU ===========>\n");
  printf("0 - Sair \n");
  printf("1 - Registro \n");
  printf("2 - Categorias \n");
  printf("3 - Relatório \n");
  printf("<============================>\n");
  scanf("%d", &resp1);
  if(resp1 == 0){
    printf("saindo...");
    break;
  }

  else if(resp1 < 0 || resp1 > 3 ){
    printf("Esta opção não existe !!! \n ");
    printf("\n ");
  }

  else if(resp1 == 1){
    MenuRegistro();
  }

 
  }while(resp1 >= 0 || resp1 <=3 );

}

  




int main(void){
struct informacoes T[100];
menu();
return 0;
}


